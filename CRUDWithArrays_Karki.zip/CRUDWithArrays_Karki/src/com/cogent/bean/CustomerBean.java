package com.cogent.bean;

public class CustomerBean /*implements Serializable*/ {
	private long customerId;
	private String customerName;
	
	public CustomerBean(long id, String name) {
		customerId = id;
		customerName = name;
	}
	public long getId() {
		return customerId;
	}
	public String getName() {
		return customerName;
	}
	public void setId(long id) {
		customerId = id;
	}
	public void setName(String name) { 
		customerName = name;
	}
}
