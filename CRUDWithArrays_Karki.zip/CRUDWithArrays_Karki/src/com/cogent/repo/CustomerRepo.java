package com.cogent.repo;
import java.util.Hashtable;
import java.util.Map;

import com.cogent.bean.CustomerBean;

public class CustomerRepo {
	private static Map<Long, String> customers = new Hashtable<Long, String>();
	public CustomerRepo() {
		
	}
	public static void addCustomer(CustomerBean customerBean) {
		customers.put(customerBean.getId(), customerBean.getName());
	}
	public static void viewAllCustomers() {
		System.out.println("List of Customers:");
		for(long l : CustomerRepo.customers.keySet()) {
			System.out.println(l + " | " + CustomerRepo.customers.get(l) + "\n");
		}
	}
	public static void customerSearch(long l) {
		if(customers.get(l) == null)
    		System.out.println("No customer with ID " + l);
		else
			System.out.println(customers.get(l));
	}
}
