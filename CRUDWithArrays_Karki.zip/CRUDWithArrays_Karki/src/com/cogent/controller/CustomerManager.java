package com.cogent.controller;
import java.util.Scanner;

import com.cogent.bean.CustomerBean;
import com.cogent.repo.CustomerRepo;

public class CustomerManager {
	public static void printMainMenu() {
		System.out.println("************************************\n" + 
				"CUSTOMER MANAGEMENT SYSTEM\n" + 
				"************************************");
		System.out.println("1. Add Customer");
		System.out.println("2. View All Customers");
		System.out.println("3. Search Customer by Id");
		System.out.println("4. Exit");
	}
	
	public static void menu() {
		String userIn;
		
		 Scanner scan = new Scanner(System.in); // Capturing the input
	        do {
	        	printMainMenu();
	        	userIn = scan.nextLine();
	            switch (userIn) {
	                case "1":
	                    System.out.println("Please enter customer ID:");
	                    long userLong;
	                    
	                    try {
	                    	userLong = scan.nextLong();
	                    	scan.nextLine();
	                    }catch(Exception e) {
	                    	System.out.println("Invalid input.");
	                    	break;
	                    }
	                    
	                    System.out.println("Please enter customer name:");
	                    userIn = scan.nextLine();
	                    CustomerRepo.addCustomer(new CustomerBean(userLong, userIn));
	                    System.out.println("Customer (" + userLong + " | " + userIn + ") successfully added.\n");
	                    break;
	                case "2":
	                    CustomerRepo.viewAllCustomers();
	                    break;
	                case "3":
	                	System.out.println("Please enter customer ID:");
	                	
	                	try {
	                    	userLong = scan.nextLong();
	                    	scan.nextLine();
	                    }catch(Exception e) {
	                    	System.out.println("Invalid input.");
	                    	break;
	                    }
	                	
	                	CustomerRepo.customerSearch(userLong);
	                    break;
	                default:
	                	break;
	            }
	        } while (!userIn.equals("4")); // exit
	}

	public static void main(String[] args) {
		menu();
	}

}
