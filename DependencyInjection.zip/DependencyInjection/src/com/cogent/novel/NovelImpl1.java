package com.cogent.novel;

public class NovelImpl1 implements Novel{
	public NovelData n;
	
	NovelImpl1(NovelData n) {
		this.n = n;
	}

	@Override
	public void printData() {
		System.out.println(n);
		
	}
	
	@Override
	public String toString() {
		return n.toString();
	}
}
