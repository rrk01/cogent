package com.cogent.novel;

import java.util.ArrayList;

public class Library {
	private ArrayList<NovelImpl1> archive = new ArrayList<NovelImpl1>();
	
	public void addNovel(NovelImpl1 n) {
		archive.add(n);
	}
	
	public String toString() {
		String toReturn = "";
		
		for(NovelImpl1 i : archive)
			toReturn += i + "\n";
		
		return toReturn;
	}

}
