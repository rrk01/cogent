package com.cogent.novel;

public class Driver {
	public static void main(String[] args) {
		NovelData nd = new NovelData("Reincarnation of the Strongest Sword God", "Lucky Old Cat", "CN");
		NovelData nd2 = new NovelData("Tales of Demons and Gods", "Mad Snail", "CN");
		NovelData nd3 = new NovelData("Re:Zero - Starting life in another world from zero", "Tappei Nagatsuki", "JP");
		NovelData nd4 = new NovelData("A Wild Last Boss Appeared!", "Firehead", "JP");
		
		NovelImpl1 novel = new NovelImpl1(nd);
		NovelImpl1 novel2 = new NovelImpl1(nd2);
		NovelImpl1 novel3 = new NovelImpl1(nd3);
		NovelImpl1 novel4 = new NovelImpl1(nd4);
		
		Library lib = new Library();
		lib.addNovel(novel);
		lib.addNovel(novel2);
		lib.addNovel(novel3);
		lib.addNovel(novel4);
		
		System.out.println(lib);
	}

}
