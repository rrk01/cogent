package com.cogent.novel;

public interface Novel {
	void printData();

}
