package com.cogent.boot.pojo;

//Setter Injection
public class Ambulance {
	public String start() {
		return "wee woo wee woo";
	}

}
