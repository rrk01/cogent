package com.cogent.boot.pojo;

import org.springframework.stereotype.Component;

@Component //@Component for Container Managed Bean
public class Car {
	public void start() {
		System.out.println("We are travelling.");
	}
}
