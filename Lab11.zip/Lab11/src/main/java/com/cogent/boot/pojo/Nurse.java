package com.cogent.boot.pojo;

import org.springframework.stereotype.Component;

@Component //Constructor Injection
public class Nurse {
	public String performCheckup() {
		return "Take your meds.";
	}
}
