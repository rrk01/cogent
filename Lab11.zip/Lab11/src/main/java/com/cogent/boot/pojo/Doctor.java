package com.cogent.boot.pojo;

import org.springframework.stereotype.Component;

@Component //Setter Injection
public class Doctor {
	public String performCheckup() {
		return "Time remaining: 10...";
	}
}
