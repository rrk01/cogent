package com.cogent.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cogent.boot.pojo.Ambulance;
import com.cogent.boot.pojo.Car;
import com.cogent.boot.pojo.Hospital;

@SpringBootApplication
public class Lab11Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Lab11Application.class, args);
		Hospital hospital = context.getBean(Hospital.class);
		hospital.open(new Ambulance());
		
		//Car car = context.getBean(Car.class);
		//car.start();
	}

}
