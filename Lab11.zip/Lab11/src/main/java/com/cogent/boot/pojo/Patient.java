package com.cogent.boot.pojo;

import org.springframework.stereotype.Component;

@Component //Field Injection
public class Patient {
	public String talk() {
		return "I require financial compensation.";
	}
}
