package com.cogent.boot.pojo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Hospital {
	
	@Autowired
	Patient patient; //Field
	
	Doctor doctor; //Setter
	@Autowired
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor; //The object "setterInjectedService" cannot be initialized without calling the setter.
	}
	
	@Autowired
	Nurse nurse; //Constructor
	public Hospital(Nurse nurse) {
		super();
		this.nurse = nurse; //The object "constructorInjectedService" is initialized here.
	}
	
	Ambulance ambulance; //Setter
	public void setAmbulance(Ambulance ambulance) {
		this.ambulance = ambulance; //The object "setterInjectedService" cannot be initialized without calling the setter.
	}
	
	public void open(Ambulance amb) {
		this.ambulance = amb;
		System.out.println(ambulance.start());
		System.out.println(patient.talk());
		System.out.println(nurse.performCheckup());
		System.out.println(doctor.performCheckup());
	}
}
