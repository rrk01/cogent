package com.cogent.service;

import com.cogent.bean.EmployeeBean;

public interface EmployeeService {
	void addEmployee(EmployeeBean employee);
	void viewEmployees();
	void searchEmployee(long id);
	void deleteEmployee(long id);
	void findYoungest();
	void displayFromCountry(String country);
	void displayFromCity(String city);

}
