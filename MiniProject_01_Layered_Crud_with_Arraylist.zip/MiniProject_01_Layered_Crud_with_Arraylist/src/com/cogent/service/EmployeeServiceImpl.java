package com.cogent.service;

import com.cogent.bean.EmployeeBean;

public class EmployeeServiceImpl implements EmployeeService{

	@Override
	public void addEmployee(EmployeeBean employee) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void viewEmployees() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void searchEmployee(long id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteEmployee(long id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void findYoungest() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayFromCountry(String country) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayFromCity(String city) {
		// TODO Auto-generated method stub
		
	}
	

}
