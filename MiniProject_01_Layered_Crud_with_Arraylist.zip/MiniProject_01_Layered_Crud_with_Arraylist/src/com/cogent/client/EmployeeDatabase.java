package com.cogent.client;

public class EmployeeDatabase {
	public static void main(String[] args) {
		
	}

}
