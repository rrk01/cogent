package com.cogent.repo;

import com.cogent.bean.EmployeeBean;

public interface EmployeeRepo {

	void addEmployee(EmployeeBean employee);
	void viewEmployees();
	void searchEmployee(long id);
	void deleteEmployee(long id);
	void findYoungest();
	void displayFromCountry(String country);
	void displayFromCity(String city);
}
