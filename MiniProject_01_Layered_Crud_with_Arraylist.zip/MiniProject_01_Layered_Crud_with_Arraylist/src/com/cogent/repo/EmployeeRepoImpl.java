package com.cogent.repo;

import java.util.ArrayList;
import java.util.List;

import com.cogent.bean.BookBean;
import com.cogent.bean.EmployeeBean;

/**
 * 
 * @author ryanr
 *
 */

public class EmployeeRepoImpl implements EmployeeRepo{
	
	List<EmployeeBean> employees = new ArrayList();

	@Override
	public void addEmployee(EmployeeBean employee) {
		employees.add(employee);
		
	}

	@Override
	public void viewEmployees() {
		for(EmployeeBean i : employees) {
			System.out.println(i);
		}
		
	}

	@Override
	public void searchEmployee(long id) {
		for(EmployeeBean i : employees) {
			if(i.getEmployeeId() == id) {
				System.out.println(i);
				return;
			}
		}
		
	}

	@Override
	public void deleteEmployee(long id) {
		for(int i = 0; i < employees.size(); i ++) {
			if(employees.get(i).getEmployeeId() == id) {
				employees.remove(i);
				return;
			}
		}
		System.out.println("Invalid ID.");
		
	}

	@Override
	public void findYoungest() {
		int youngest = Integer.MAX_VALUE;
		EmployeeBean aux = new EmployeeBean();
		for(EmployeeBean i : employees) {
			if(i.getEmployeeAge() < youngest) {
				youngest = i.getEmployeeAge();
				aux = i;
			}
		}
		System.out.println("YOUNGEST EMPLOYEE:\n" + aux);
		
	}

	@Override
	public void displayFromCountry(String country) {
		System.out.println("EMPLOYEE(S) FROM " + country);
		for(int i = 0; i < employees.size(); i ++) {
			if(employees.get(i).getEmployeeCountry().equals(country)) {
				System.out.println(employees.get(i));
			}
		}
		
	}

	@Override
	public void displayFromCity(String city) {
		System.out.println("EMPLOYEE(S) FROM " + city);
		for(int i = 0; i < employees.size(); i ++) {
			if(employees.get(i).getEmployeeCountry().equals(city)) {
				System.out.println(employees.get(i));
			}
		}
	}

}
